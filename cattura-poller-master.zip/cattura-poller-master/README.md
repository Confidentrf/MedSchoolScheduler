# Cattura Poller #

### Description ###

This is a script which is meant to check the reachability via cURL of IP addresses located in an INI file

Currently set to poll each unit every 10 minutes via cron on LULCS02 from 2am to 11pm:

    cat /etc/cron.d/catturaEndpointPoller

    */10 2-23 * * * root . $HOME/.bash_profile ; cd /var/core/util/cattura && php /var/core/util/cattura/catturaEndpointPoller.php > /dev/null 2>&1

### Dependencies ###

* GrayLogger.php in /var/core/classes/GrayLogger/