<?php

/*

Create a utility that will poll Cattura units and confirm that they are still accessible via HTTP. 

We can probably have this run every 10 minutes via a cronjob.

When a unit is inaccessible the utility will need to email telepresenceservice@liberty.edu with information about which unit it inaccessible. 
Also accout for the the maintenance window from 0000 to 01000 hours every night (possibly just make the job not run during that time)

Lastly ensure that no more than one email is sent per unit. 

*/


require_once("GrayLogger/GrayLogger.php");

class catturaBox
{
	public $name;
	public $ip;
	public $ch;

	public function __construct($name,$ip,$ch){
		$this->name = $name;
		$this->ip 	= $ip;
		$this->ch	= $ch;
	}
}

class EndpointPoller 
{
	# Hard coded defaults in case the values aren't set in the INI file

	protected static $send_email 		= false;
	protected static $curl_timeout 		= 15;
	protected static $cattura_units 	= [];
	protected static $date_format 		= "Y-m-d H:i:s";
	protected static $data_file 		= 'notification_data.txt';
	protected static $email_recipients 	= ['telepresenceservice@liberty.edu'];
	
	protected static $offlineBoxes 		= [];
	protected static $nowOnlineBoxes 	= [];
	protected static $logger;
	protected static $hostname;

	private static function init()
	{
		$config = parse_ini_file('cattura_poller.ini',true);

		self::$cattura_units 		= isset($config['cattura_units']) 
			? $config['cattura_units'] 					: ['localhost','127.0.0.1'];

		self::$email_recipients 	= isset($config['settings']['email_recipients']) 
			? $config['settings']['email_recipients'] 	: self::$email_recipients;

		self::$email_recipients 	= implode(',',self::$email_recipients);

		self::$curl_timeout 		= isset($config['settings']['curl_timeout']) 
			? $config['settings']['curl_timeout'] 		: self::$curl_timeout;

		self::$date_format 			= isset($config['settings']['date_format'])
			? $config['settings']['date_format']		: self::$date_format;

		self::$data_file 			= isset($config['settings']['data_file'])
			? $config['settings']['data_file']			: self::$data_file;

		self::$send_email 			= isset($config['settings']['send_email'])
			? $config['settings']['send_email']			: self::$send_email;
		
		if (self::$send_email == 'false') { self::$send_email = false; }
		if (self::$send_email == 'true')  { self::$send_email = true;  }

		# Check that the $data_file.txt exists
		if(!file_exists(self::$data_file)){
			file_put_contents(self::$data_file,'');
		}

		self::$logger 				= new GrayLogger(
			[
				'log_level'		=>	GrayLogger::LEVEL_DEBUG, 
				'graylog_level'	=>	GrayLogger::LEVEL_INFO
			]
		);
		self::$hostname 			= exec('hostname');
	}

	private static function handleOnlineBox($box)
	{
		$name = $box->name;
		$message = "";

		$notificationData = file_get_contents(self::$data_file);
		if($notificationData !== false)
		{
			$notificationData = json_decode($notificationData,true);
			if (isset($notificationData[$box->ip]))
			{
				unset($notificationData[$box->ip]);
				file_put_contents(self::$data_file,json_encode($notificationData));
				SELF::$logger->notice("$name was previously offline but is now online");
				self::$nowOnlineBoxes[] = $box;
			}else{
				$message = "Online: $name";
			}
		}else{
			$message = "Online: $name";
		}
		SELF::$logger->debug($message);
	}

	private static function handleOfflineBox($box, Exception $exception = null)
	{
		$offlineBoxes = self::$offlineBoxes;
		$exception = is_a($exception, 'Exception') ? $exception : new Exception("An error occurred...");
		$errorMessage = $exception->getMessage();
		$notificationData = file_get_contents(self::$data_file);
		if($notificationData !== false)
		{
			$notificationData = json_decode($notificationData,true);
			if (isset($notificationData[$box->ip]) === false)
			{
				$notificationData[$box->ip] = date(self::$date_format);
				$offlineBoxes[] = [$box,$errorMessage];
				self::$logger->notice("{$box->name} is offline. (New)",['exception'=>$exception]);
			}else
			{
				#$interval = date_diff(new DateTime(),new DateTime($notificationData[$box->ip]));
				$name = $box->name;
				SELF::$logger->info("{$box->name} is offline. (Already Notified)",['exception'=>$exception]);
			}
			file_put_contents(self::$data_file,json_encode($notificationData));
		}else
		{
			$notificationData[$box->ip] = true;
			file_put_contents(self::$data_file,json_encode($notificationData));
			$offlineBoxes[] = [$box,$errorMessage];
		}
		self::$offlineBoxes = $offlineBoxes;
	}

	private static function sendOfflineEmail(array $offlineBoxes)
	{
		ini_set("SMTP","mail.liberty.edu");
		// Multiple recipients
		$to = self::$email_recipients; 

		// Subject
		$subject = 'Cattura units Offline';

		// Message
		$message = '
			<html>
			<head>
				<title>Cattura units Offline</title>
			</head>
			<style>
			tr:hover {
				background-color: #f5f5f5
			}
			table{
				verticle-align: center;
			}
			th{
				text-align: center;
			}
			tr, td {
				padding:0px 25px;
			}
			table , tr , th , td{
				border-collapse: collapse;
				border: 1px solid black;
			}
			</style>
			<body>
				<p>One or more Cattura units are unreachable:</p>
			<table border=1>
			<tr>
				<th>Room</th><th>Address</th><th>Error Message</th>
			</tr>
		';
		foreach($offlineBoxes as $boxArr){
			$box = $boxArr[0];
			$name = $box->name;	
			$addr = 'http://' . $box->ip . '';
			$message .= "
				<tr>
					<td>$name</td><td><a href='$addr'>$addr</td><td>$boxArr[1]</td>
				</tr>
			";

			SELF::$logger->info("--> Offline: $name (Sending Email)");
		}

		$message .= 
		'
			</table>
			</body>
			</html>
		';

		// To send HTML mail, the Content-type header must be set
		$headers[] = 'MIME-Version: 1.0';
		$headers[] = 'Content-type: text/html; charset=iso-8859-1';

		// Additional headers
		#$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
		$headers[] = "From: Cattura Poller on " . SELF::$hostname . " <telepresenceservice@liberty.edu>";

		// Mail it
		if(self::$send_email){
			mail($to, $subject, $message, implode("\r\n", $headers));
		} else {
			echo "\n Offline Email: \n";
			var_dump($message);
		}
		SELF::$logger->info("Offline Email sent");
		#SELF::$logger->debug("Offline Email contents",['to'=>$to,'subject'=>$subject,'message'=>$message,'headers'=>$headers]);
	}

	private static function sendOnlineEmail(array $nowOnlineBoxes)
	{
		ini_set("SMTP","mail.liberty.edu");
		// Multiple recipients
		$to = self::$email_recipients; 

		// Subject
		$subject = 'Previously Offline Cattura Units are now Online';

		// Message
		$message = '
			<html>
			<head>
				<title>Cattura units now Online</title>
			</head>
			<style>
			tr:hover {
				background-color: #f5f5f5
			}
			table{
				verticle-align: center;
			}
			th{
				text-align: center;
			}
			tr, td {
				padding:0px 25px;
			}
			table , tr , th , td{
				border-collapse: collapse;
				border: 1px solid black;
			}
			</style>
			<body>
				<p>The following Cattura units were previously Offline but are now back Online:</p>
			<table border=1>
			<tr>
				<th>Room</th><th>Address</th>
			</tr>
		';
		foreach($nowOnlineBoxes as $box){
			$name = $box->name;	
			$addr = 'http://' . $box->ip . '';
			$message .= "
				<tr>
					<td>$name</td><td><a href='$addr'>$addr</td>
				</tr>

			";

			SELF::$logger->info("--> Previously offline, now online: $name (Sending Email)");
		}

		$message .= 
		'
			</table>
			</body>
			</html>
		';

		// To send HTML mail, the Content-type header must be set
		$headers[] = 'MIME-Version: 1.0';
		$headers[] = 'Content-type: text/html; charset=iso-8859-1';

		// Additional headers
		#$headers[] = 'To: Mary <mary@example.com>, Kelly <kelly@example.com>';
		$headers[] = "From: Cattura Poller on " . SELF::$hostname . " <telepresenceservice@liberty.edu>";

		// Mail it
		if(self::$send_email){
			mail($to, $subject, $message, implode("\r\n", $headers));
		} else {
			echo "\n Online Email: \n";
			var_dump($message);
		}
		SELF::$logger->info("Online Email sent");
		#SELF::$logger->debug("Online Email contents",['to'=>$to,'subject'=>$subject,'message'=>$message,'headers'=>$headers]);
	}
 
	public static function run()
	{
		self::init();
		# "MAIN" Script Functionality
		# Checks whether each cattura unit (using the IP retrieved from the INI file) is curl-able
		# and adds any unit that is unreachable to the $offlineBoxes array 
		# The self::sendOfflineEmail function will send one email containing all $offlineBoxes to the constant defined address

		$multi_handle = curl_multi_init();
		$cattura_boxes = [];
		foreach(self::$cattura_units as $name => $ip){
			$cattura_boxes[] = new catturaBox($name,$ip,curl_init($ip));
			$last_box = end($cattura_boxes);
			curl_setopt($last_box->ch, CURLOPT_CONNECTTIMEOUT, self::$curl_timeout);
			curl_setopt($last_box->ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($last_box->ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_multi_add_handle($multi_handle, $last_box->ch);
		}

		# Reset the internal pointer for $cattura_boxes->ch
		reset($cattura_boxes);
	
		// execute all queries simultaneously, and continue when all are complete
		$running = null;
		do {
			try {
				curl_multi_exec($multi_handle, $running);
			} catch (Exception $e) {
				self::$log->error("Caught exception while executing multi curl", ['exception' => $e]);
				exit;
			}
		} while ($running);

		# Loop and process each executed handle for each cattura box
		foreach($cattura_boxes as $box){
			$ch = $box->ch;
			$content = curl_multi_getcontent($ch);
			$errno = curl_errno($ch);
			$info = curl_getinfo($ch);
			$err = curl_error($ch);

			if($errno != 0 || $err != "" || $info['http_code'] >= 400) {
				if($err != ""){
					$ex = new Exception($err);
				} elseif ($err == "" && $info['http_code'] >= 400) {
					$ex = new Exception("cURL Failed with HTTP Code: " . $info['http_code']);
				} elseif (curl_strerror($errno) != "") {
					$ex = new Exception(curl_strerror($errno));
				} else {
					$ex = new Exception("An unknown cURL error occurred");
				}
				self::handleOfflineBox($box, $ex);
			} else {
				self::handleOnlineBox($box);
			}

			# Close up the handles
			curl_multi_remove_handle($multi_handle,$ch);
			curl_close($ch);
		}

		# Close the multi handle
		curl_multi_close($multi_handle);
			
		# Send email for any offline cattura boxes
		if(count(self::$offlineBoxes) > 0){
			self::sendOfflineEmail(self::$offlineBoxes);
		}

		# Send email for any cattura box that was offline but is now online
		if(count(self::$nowOnlineBoxes) > 0){
			self::sendOnlineEmail(self::$nowOnlineBoxes);
		}
	}
}

EndpointPoller::run();

?>